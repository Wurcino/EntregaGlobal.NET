
# SolarEnergyStore.Api

## Descri��o do Projeto

O **SolarEnergyStore.Api** � uma API que gerencia equipamentos el�tricos em uma empresa utilizando dados de sensores conectados a um Arduino. A API permite:

- Registro de temperaturas internas e externas dos equipamentos.
- Monitoramento e controle dos per�odos de funcionamento.
- Integra��o com um banco de dados relacional para persist�ncia de dados.

### Tecnologias Utilizadas

- **ASP.NET Core 8.0**: Framework para constru��o de APIs modernas.
- **Entity Framework Core**: ORM para interagir com o banco de dados.
- **SQL Server**: Banco de dados relacional.
- **Arduino**: Coleta de dados de sensores (temperatura e proximidade).
- **Swagger**: Documenta��o e testes interativos da API.

---

## Estrutura do Projeto

A solu��o est� dividida em m�ltiplos projetos para separar responsabilidades e melhorar a manuten��o:

1. **SolarEnergyStore.Api**: 
   - Cont�m os controllers que exp�em os endpoints da API.
   - Configura��o de depend�ncias e inicializa��o da aplica��o.
2. **SolarEnergyStore.Models**:
   - Cont�m as classes de modelo (entidades) que representam as tabelas do banco de dados.
3. **SolarEnergyStore.Repositories**:
   - Camada de acesso ao banco de dados utilizando o Entity Framework Core.
   - Cont�m a implementa��o do `DbContext`.
4. **SolarEnergyStore.Services**:
   - Cont�m a l�gica de neg�cios e valida��es.
5. **SolarEnergyStore.Tests**:
   - Testes unit�rios para garantir a qualidade do c�digo.

---

## Pr�-requisitos

Antes de come�ar, voc� precisa instalar as seguintes ferramentas:

- [.NET SDK](https://dotnet.microsoft.com/) (vers�o 8.0 ou superior)
- [SQL Server](https://www.microsoft.com/sql-server)
- [Arduino IDE](https://www.arduino.cc/en/software) (para o c�digo do Arduino)
- Um cliente de API, como [Postman](https://www.postman.com/) ou [Insomnia](https://insomnia.rest/), para testes manuais.

---

## Endpoints Dispon�veis

Os principais endpoints est�o documentados via **Swagger**. Ap�s iniciar a aplica��o, acesse:

```
https://localhost:5001/swagger/index.html
```

Voc� ver� uma interface interativa com a documenta��o completa da API e poder� realizar testes diretamente por l�.

## Testes

Para executar os testes unit�rios, use o seguinte comando no terminal:

```bash
cd SolarEnergyStore.Tests
dotnet test
```

O resultado dos testes ser� exibido no terminal, incluindo detalhes de qualquer falha.

---

## Como Funciona a Integra��o com o Arduino

O Arduino coleta dados de sensores e envia para a API por meio de requisi��es HTTP. Aqui est� uma vis�o geral:

1. **Sensores**:
   - **Proximidade**: Detecta a presen�a de pessoas para ligar ou desligar os equipamentos.
   - **Temperatura**: Monitora a temperatura interna e externa dos equipamentos.

2. **Fluxo**:
   - O Arduino envia os dados para os endpoints da API utilizando comandos HTTP (via biblioteca Arduino `HTTPClient`).
   - A API processa os dados, armazena no banco de dados e retorna as respostas adequadas ao Arduino.
